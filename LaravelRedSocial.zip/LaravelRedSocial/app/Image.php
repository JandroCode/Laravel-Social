<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $table = 'images';

    //UNA IMAGEN MUCHOS COMENTARIOS(UNO A MUCHOS)
    public function comments(){
        return $this->hasMany('App\Comment');
    }
    //UNA IMAGEN MUCHOS LIKES(UNO A MUCHOS)
    public function likes(){
        return $this->hasMany('App\Likes');
    }

    //MUCHAS IMÁGENES UN USUARIO(MUCHOS A UNO)
    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }
}
