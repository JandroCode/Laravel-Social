<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table = 'comments';

    //MUCHOS COMENTARIOS UN USUARIO(MUCHOS A UNO)
    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }

    //MUCHOS COMENTARIOS UNA IMAGEN(MUCHOS A UNO)
    public function image(){
        return $this->belongsTo('App\User','user_id');
    }

}
