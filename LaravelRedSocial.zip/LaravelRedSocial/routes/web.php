<?php

use App\Image;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
//Ruta para la configuración
Route::get('/config','UserController@config')->name('config');
//Ruta para actualizar los datos de los usuarios
Route::post('/user/edit','UserController@update')->name('user.update');
//Ruta para obtener la foto del perfil
Route::get('/user/avatar/{filename}','UserController@getImage')->name('user.avatar');
